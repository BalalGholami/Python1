print("contact.py initialized")
