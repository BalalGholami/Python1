

from ecommerce.shopping import sales


def contact_customer():
    print("contact_ customer in customer package")


sales.calc_tax()
