print("ECommerce Initizlized")
