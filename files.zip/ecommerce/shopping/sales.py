# sales
#from ecommerce.customer import contact

print("sales initialized", __name__)


def calc_tax():
    print("Calc Tax in sales.py")


def calc_interest():
    print("Calc Interest in sales.py")


if __name__ == "__main__":
    print("sales is main")
else:
    print("sales is not main")
