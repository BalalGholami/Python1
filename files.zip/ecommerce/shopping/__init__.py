print("sales is initialized")
